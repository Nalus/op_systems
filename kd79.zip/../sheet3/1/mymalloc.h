void* mymalloc (size_t input);
void myfree (void* finger);
