void* findMem(void* mem);
void printFrees();
void* mymalloc (size_t input);
void myfree (void* finger);
